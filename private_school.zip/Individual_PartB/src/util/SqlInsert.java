package util;

import java.util.InputMismatchException;
import java.util.Scanner;

import dao.*;

public class SqlInsert {
	private Scanner sc = new Scanner(System.in);

	public SqlInsert() {
	}

	public void SqlInsertInit() {

		int subMenuChoice = 1;

		boolean flag = true;
		while (subMenuChoice != 0 && flag == true) {
			printSubMenu();
			try {
			System.out.print("Type your choice here : ");
			subMenuChoice = sc.nextInt();
			switch (subMenuChoice) {
			case 0:
				System.out.println("\t---------- Program terminated normally ---------- ");
				flag = false;

				break;
			case 1:
				new DaoStudent();
				System.out.println("-----------------------------------------------------");
				break;
			case 2:
				new DaoTrainer();
				System.out.println("-----------------------------------------------------");
				break;
			case 3:
				new DaoAssignment();
				System.out.println("-----------------------------------------------------");
				break;
			case 4:
				new DaoCourse();
				break;
			case 5:
             DaoCourse.studentToCourse();
				break;
			case 6:
             DaoTrainer.trainerToCourse();
				break;
			case 7:
             DaoAssignment.assignmentsPerStudentPerCourse();
				break;
			default:
				System.out.println("Wrong input try again ");
				break;
			}
			}catch (InputMismatchException e) {
	            System.out.println("Please give a number");
	            sc.next();
	        }
		}

	}

	public static void printSubMenu() {
		System.out.println("\n--------------------- DB INPUTS ---------------------");
		System.out.println("Type : ");
		System.out.println("\t\t1. to insert a student");
		System.out.println("\t\t2. to insert a trainer");
		System.out.println("\t\t3. to insert an assignment");
		System.out.println("\t\t4. to insert a course");
		System.out.println("\t\t5. to insert students per course");
		System.out.println("\t\t6. to insert trainers per course");
		System.out.println("\t\t7. to insert assignments per course per student");
		System.out.println("\t\t0. to exit ");
	}

}

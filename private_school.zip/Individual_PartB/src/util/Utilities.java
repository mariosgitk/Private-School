package util;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Utilities {

	public static Connection conn = null;

	public static void connect() {

		String url = "jdbc:mysql://localhost:3306/private_school?useSSL=false";
		try {
			conn = DriverManager.getConnection(url, "admin", "12345!@#$%");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Kati den pige kala me tin vasi dedomenon");
		}
	}

	public static void closeDataBase() {

		try {
			conn.close();
			// System.out.println("Connection Terminated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Kati den pige kala me tin vasi dedomenon");
		}
	}

	public static ResultSet selectAll(String tableName) {
		ResultSet rs = null;
		connect();
		String sql = "Select * from  private_school." + tableName;
		try {
			Statement st = conn.createStatement();
			rs = st.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;

	}

}

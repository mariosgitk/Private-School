package util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;
import dao.*;

public class SqlQuery {
	private Scanner sc;

	public SqlQuery() {
	}

	public void SqlInit() {
		int menuChoice = 1;
		sc = new Scanner(System.in);
		boolean flag = true;
		while (menuChoice != 0 && flag == true) {
			printMenu();
			try {
			System.out.print("Type your choice here : ");
			menuChoice = sc.nextInt();
			switch (menuChoice) {
			case 0:
				System.out.println("\t---------- Program terminated normally ---------- ");
				flag = false;

				break;
			case 1:
				Utilities.connect();
				ResultSet rs1 = null;
				rs1 = Utilities.selectAll("student");
				System.out.println("\n\nFirst Name" + "\t" + "Last Name");
				System.out.println("-----------------------------------------------------");
				try {
					while (rs1.next()) {
						System.out.println(rs1.getString("first_name") + "\t\t" + rs1.getString("last_name"));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("-----------------------------------------------------");
				Utilities.closeDataBase();
				break;
			case 2:
				Utilities.connect();
				ResultSet rs2 = null;
				rs2 = Utilities.selectAll("trainer");
				System.out.println("\n\nFirst Name" + "\t" + "Last Name" + "\t" + "subject");
				System.out.println("-----------------------------------------------------");
				try {
					while (rs2.next()) {
						System.out.println(rs2.getString("first_name") + "\t\t" + rs2.getString("last_name") + "\t\t"
								+ rs2.getString("subject"));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("-----------------------------------------------------");
				Utilities.closeDataBase();
				break;
			case 3:
				Utilities.connect();
				ResultSet rs3 = null;
				rs3 = Utilities.selectAll("assignment");
				System.out.println("\n\n title");
				System.out.println("-----------------------------------------------------");
				try {
					while (rs3.next()) {
						System.out.println(rs3.getString("titlea"));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("-----------------------------------------------------");
				Utilities.closeDataBase();
				break;
			case 4:
				Utilities.connect();
				ResultSet rs4 = null;
				rs4 = Utilities.selectAll("course");
				System.out.println("\n\n title");
				System.out.println("-----------------------------------------------------");
				try {
					while (rs4.next()) {
						System.out.println(rs4.getString("titlec"));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("-----------------------------------------------------");
				Utilities.closeDataBase();
				break;
			case 5:
				DaoStudent.selectStudentPerCourse();
				break;
			case 6:
				DaoTrainer.selectTrainerPerCourse();
				break;
			case 7:
				DaoAssignment.selectAssignmentPerCourse();
				break;
			case 8:
				DaoAssignment.selectAssignmentPerCoursePerStudent();
				break;
			case 9:
				DaoStudent.selectStudentsWithMoreThanOneCourse();
				break;
			default:
				System.out.println("Wrong input try again ");
				break;
			}
			}catch (InputMismatchException e) {
	            System.out.println("Please give a number");
	            sc.next();
	        }
		}
	}

	public static void printMenu() {
		System.out.println("\n--------------------- DB QUERIES ---------------------");
		System.out.println("Type : ");
		System.out.println("\t\t1. for a list of all the students");
		System.out.println("\t\t2. for a list of all the trainers");
		System.out.println("\t\t3. for a list of all the assignments");
		System.out.println("\t\t4. for a list of all the courses");
		System.out.println("\t\t5. for all the students per course");
		System.out.println("\t\t6. for all the trainers per course");
		System.out.println("\t\t7. for all the assignments per course");
		System.out.println("\t\t8. for all the assignments per course per student");
		System.out.println("\t\t9. for a list of all the students with more than one course");
		System.out.println("\t\t0. to exit ");
	}

}
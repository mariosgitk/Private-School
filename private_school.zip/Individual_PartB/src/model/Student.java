package model;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Ro Mario
 */
public class Student {
    private String name;
   private String surName;
   private String birthDate;
   private int tuitionFees;
   
   
   
    public Student(String name, String surName, String birthDate, int tuitionFees) {
        this.name = name;
        this.surName = surName;
        this.birthDate = birthDate;
        this.tuitionFees = tuitionFees;
    }

    
  
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getSurName() {
        return surName;
    }
    
    public void setSurName(String surName) {
        this.surName = surName;
    }
    
    
    public String getBirthDate() {
        return birthDate;
    }
    
    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }
    
    public int getTuitionFees() {
        return tuitionFees;
    }
    
    public void setTuitionFees(int tuitionFees) {
        this.tuitionFees = tuitionFees;
    }

    @Override
    public String toString() {
        return  name + "  " + surName;
    }
    

    
}

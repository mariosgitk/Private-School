import java.util.InputMismatchException;
import java.util.Scanner;



import util.*;
public class Main {
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SqlQuery q1 = new SqlQuery();
		SqlInsert i1 = new SqlInsert();
		int i = 10;
		
	while (i!= 0) {
		mainMenu();
		try {
		i = sc.nextInt();
		if( i == 1) {
			q1.SqlInit();
		}
		else if ( i == 2 ) {
			i1.SqlInsertInit();
		}
		else if (i == 0 ) {
			System.out.println("Programm terminated normally");
			sc.close();
			break;
		}
		else { System.out.println(" Wrong input try again ");
		continue;
		}
		}
		catch (InputMismatchException e) {
            System.out.println("Please give a number");
            sc.next();
        }
	}
	}

	public static void mainMenu() {
		
		System.out.println("--------Welcome--------");
		System.out.println("Type :");
		System.out.println("1. To see the reports of the private school ");
		System.out.println("2. To insert entries into the private school ");
		System.out.println("0. To terminate and exit ");
		
	}
}

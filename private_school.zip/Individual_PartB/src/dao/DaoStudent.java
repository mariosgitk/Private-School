package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import util.Utilities;

public class DaoStudent {

	private Scanner sc;

	public DaoStudent() {
		sc = new Scanner(System.in);

		String[] ar = { "", "", "", "" };
		System.out.println("Dwse mou to first name tou student ");
		ar[0] = sc.next();
		System.out.println("Dwse mou to last name tou student ");
		ar[1] = sc.next();
		System.out.println("Dwse mou to date of birth tou student (YYYY-MM-DD)");
		ar[2] = sc.next();
		System.out.println("Dwse mou to tuition fee tou student ");
		ar[3] = sc.next();

		if (!insertStudent(ar))
			System.out.println("Den sothike sosta o neos Student");
		else {
			System.out.println("O spoudastis " + ar[0] + " " + ar[1] + " kataxorithike epitixos ");
		}

	}

	public static boolean insertStudent(String[] fieldValues) {
		String sql = "INSERT INTO `private_school`.`student` (`first_name`, `last_name`, `date_of_birth`, `tuition_fees`) VALUES (?,?,?,?)";
		Utilities.connect();

		try {

			PreparedStatement pstmt = Utilities.conn.prepareStatement(sql);
			pstmt.setString(1, fieldValues[0]);
			pstmt.setString(2, fieldValues[1]);
			pstmt.setString(3, fieldValues[2]);
			pstmt.setInt(4, Integer.parseInt(fieldValues[3]));
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Kati den pige kala me th vasi dedomenwn ");
			Utilities.closeDataBase();
			return false;
		}
		Utilities.closeDataBase();
		return true;
	}

	public static void selectStudentPerCourse() {
		Utilities.connect();
		ResultSet rsCourse = null;
		ResultSet rsStudent = null;

		String sql = "select distinct idc from student_has_course order by idc ";

		try {
			Statement st = Utilities.conn.createStatement();
			rsCourse = st.executeQuery(sql);
			while (rsCourse.next()) {
				int courseId = rsCourse.getInt("idc");
				System.out.println("Student per course cb" + courseId + " : ");
				String sql1 = "select first_name, last_name from Student where ids in (select ids from student_has_course where idc ="
						+ courseId + ")";
				Statement st1 = Utilities.conn.createStatement();
				rsStudent = st1.executeQuery(sql1);
				while (rsStudent.next()) {
					System.out.println(
							"\t\t " + rsStudent.getString("first_name") + " " + rsStudent.getString("last_name"));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Utilities.closeDataBase();
	}

	public static void selectStudentsWithMoreThanOneCourse() {

		Utilities.connect();
		String studentFirstName = "";
		String studentLastName = "";
		ResultSet rsCourse = null;
		ResultSet rsStudent = null;
		ResultSet rsStudentsCourse = null;
		String sql = "select  ids , first_name , last_name from student order by ids ";

		try {
			Statement st = Utilities.conn.createStatement();
			rsStudent = st.executeQuery(sql);
			int size;
			while (rsStudent.next()) {
				size = 0;
				int studentId = rsStudent.getInt("ids");
				studentFirstName = rsStudent.getString("first_name");
				studentLastName = rsStudent.getString("last_name");
				String sql4 = "select idc from student_has_course where ids = " + studentId;
				Statement st4 = Utilities.conn.createStatement();
				rsCourse = st4.executeQuery(sql4);
				if (rsCourse != null) {
					rsCourse.last();
					size = rsCourse.getRow();
					rsCourse.beforeFirst();
					if (size >= 2) {
						System.out.println("O spoudastis " + studentFirstName + " " + studentLastName
								+ " einai gramenos sta courses : ");
						while (rsCourse.next()) {
							String sql2 = "select titlec from course where idc = " + rsCourse.getInt("idc");
							Statement st2 = Utilities.conn.createStatement();
							rsStudentsCourse = st2.executeQuery(sql2);
							rsStudentsCourse.next();
							System.out.println("\t\t " + rsStudentsCourse.getString("titlec"));
						}
					}
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Utilities.closeDataBase();
	}

}

package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


import util.Utilities;

public class DaoCourse {

	private static Scanner sc;
	

	public DaoCourse() {
		sc = new Scanner(System.in);

		String[] ar = { "", "", "", "" };
		System.out.println("Dwse mou to onoma tou course ");
		ar[0] = sc.next();
		System.out.println("Dwse mou to stream tou course ");
		ar[1] = sc.next();
		System.out.println("Dwse mou imerominia enarksis tou course");
		ar[2] = sc.next();
		System.out.println("Dwse mou imerominia liksis tou course");
		ar[3] = sc.next();

		if (!insertCourse(ar))
			System.out.println("Den sothike sosta to neo course ");
		else {
			System.out.println("To course " + ar[0] + " " + " kataxorithike epitixos ");
		}

	}

	public static boolean insertCourse(String[] fieldValues) {
		String sql = "INSERT INTO `private_school`.`course` (`titlec`, `stream`, `start_date`, `end_date`) VALUES (?,?,?,?)";
		Utilities.connect();

		try {

			PreparedStatement pstmt = Utilities.conn.prepareStatement(sql);
			pstmt.setString(1, fieldValues[0]);
			pstmt.setString(2, fieldValues[1]);
			pstmt.setString(3, fieldValues[2]);
			pstmt.setString(4, fieldValues[3]);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Kati den pige kala me th vasi dedomenwn ");
			Utilities.closeDataBase();
			return false;
		}
		Utilities.closeDataBase();
		return true;
	}

	public static void studentToCourse() {
		sc = new Scanner(System.in);
		Utilities.connect();
		String sql = "select ids , first_name , last_name from student";
		String sql2 = "select idc , titlec from course";
		System.out.println("\t\t---- Student table -----");
		try {
			Statement st = Utilities.conn.createStatement();
			ResultSet rsStudent = st.executeQuery(sql);
			while (rsStudent.next()) {
				System.out.println("\t\t" + rsStudent.getInt("ids") + " " + rsStudent.getString("first_name") + " "
						+ rsStudent.getString("last_name"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("\t\t---- Course table -----");
		try {
			Statement st = Utilities.conn.createStatement();
			ResultSet rsCourse = st.executeQuery(sql2);
			while (rsCourse.next()) {
				System.out.println("\t\t" + rsCourse.getInt("idc") + " " + rsCourse.getString("titlec"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("\ndwse mou to student id pou 8a graftei se course");
		int studentId = sc.nextInt();
		System.out.println("dwse mou to course id pou 8a eggrafei ");
		int courseId = sc.nextInt();
		String sql3 = "insert into student_has_course (ids,idc) values (?,?)";
		try {
			PreparedStatement pstmt = Utilities.conn.prepareStatement(sql3);
			pstmt.setInt(1, studentId);
			pstmt.setInt(2, courseId);
			pstmt.executeUpdate();
			System.out.println(
					"O mathitis me id " + studentId + " kataxorithike epitixos sto course me id " + courseId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(
					"O mathitis me id " + studentId + " exei idi kataxorithei sto course me id " + courseId);

		}
	
		Utilities.closeDataBase();
	}

}

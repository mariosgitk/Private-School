package dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import util.Utilities;

public class DaoAssignment {

	
	private static Scanner sc;

	public DaoAssignment() {
		sc = new Scanner(System.in);

		String ar = "";
		System.out.println("Dwse mou to onoma tou assignment ");
		ar = sc.next();	
		if (!insertAssignment(ar))
			System.out.println("Den sothike sosta to neo assignment ");
		else {
			System.out.println("To assignment " + ar + " kataxorithike epitixos ");
		}
	}
	
	
	
		public static boolean insertAssignment(String fieldValues) {
			String sql = "INSERT INTO `private_school`.`assignment` (`titlea`) VALUES (?)";
			Utilities.connect();

			try {

				PreparedStatement pstmt = Utilities.conn.prepareStatement(sql);
				pstmt.setString(1,fieldValues);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Kati den pige kala me th vasi dedomenwn ");
				Utilities.closeDataBase();
				return false;
			}
			Utilities.closeDataBase();
			return true;
		}
		
		
		public static void selectAssignmentPerCourse() {
			Utilities.connect();
			ResultSet rsCourse = null;
			ResultSet rsAssignment = null;

			String sql = "select distinct idc from assignment_has_student_and_course order by idc ";

			try {
				Statement st = Utilities.conn.createStatement();
				rsCourse = st.executeQuery(sql);
				while (rsCourse.next()) {
					int courseId = rsCourse.getInt("idc");
					System.out.println("Assignment per course cb" + courseId + " : ");
					String sql1 = "select titlea from Assignment where ida in (select ida from assignment_has_student_and_course where idc ="
							+ courseId + ")";
					Statement st1 = Utilities.conn.createStatement();
					rsAssignment = st1.executeQuery(sql1);
					while (rsAssignment.next()) {
						System.out.println("\t\t " + rsAssignment.getString("titlea"));
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Utilities.closeDataBase();
		}
		
		public static void selectAssignmentPerCoursePerStudent() {
			Utilities.connect();
			String AssignmentName = "";
			ResultSet rsCourse = null;
			ResultSet rsAssignment = null;
			ResultSet rsStudent = null;
			ResultSet rsStudentsAssig = null;
			String sql = "select distinct idc from assignment_has_student_and_course order by idc ";

			try {
				Statement st = Utilities.conn.createStatement();
				rsCourse = st.executeQuery(sql);

				while (rsCourse.next()) {
					int courseId = rsCourse.getInt("idc");
					String sql4 = "select * from assignment_has_student_and_course where idc = " + courseId;
					Statement st4 = Utilities.conn.createStatement();
					rsStudentsAssig = st4.executeQuery(sql4);
					while (rsStudentsAssig.next()) {
						int StudentID = rsStudentsAssig.getInt("ids");
						int AssignmentID = rsStudentsAssig.getInt("ida");
						String sql2 = "select titlea from assignment where ida = " + AssignmentID;
						Statement st2 = Utilities.conn.createStatement();
						rsAssignment = st2.executeQuery(sql2);
						rsAssignment.next();
						AssignmentName = rsAssignment.getString("titlea");
						System.out.println("Course cb" + courseId + " and assignment " + AssignmentName + " : ");
						String sql3 = "select first_name , last_name from student where ids =" + StudentID;
						Statement st1 = Utilities.conn.createStatement();
						rsStudent = st1.executeQuery(sql3);
						while (rsStudent.next()) {
							System.out.println(
									"\t\t " + rsStudent.getString("first_name") + " " + rsStudent.getString("last_name"));
						}
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Utilities.closeDataBase();
		}
	
		
		public static void assignmentsPerStudentPerCourse() {
			sc = new Scanner(System.in);
			Utilities.connect();
			String sql = "select ids , first_name , last_name from student";
			String sql2 = "select idc , titlec from course";
			String sql3 = "select ida , titlea from assignment";
			
			System.out.println("\t\t---- Student table -----");
			try {
				Statement st = Utilities.conn.createStatement();
				ResultSet rsStudent = st.executeQuery(sql);
				while (rsStudent.next()) {
					System.out.println("\t\t" + rsStudent.getInt("ids") + " " + rsStudent.getString("first_name") + " "
							+ rsStudent.getString("last_name"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("\t\t---- Course table -----");
			try {
				Statement st = Utilities.conn.createStatement();
				ResultSet rsCourse = st.executeQuery(sql2);
				while (rsCourse.next()) {
					System.out.println("\t\t" + rsCourse.getInt("idc") + " " + rsCourse.getString("titlec"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("\t\t---- Assignment table -----");
			try {
				Statement st = Utilities.conn.createStatement();
				ResultSet rsAssignment = st.executeQuery(sql3);
				while (rsAssignment.next()) {
					System.out.println("\t\t" + rsAssignment.getInt("ida") + " " + rsAssignment.getString("titlea"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("\nDwse mou to id tou assignment ");
			int assignmentId = sc.nextInt();
			System.out.println("Dwse mou to id tou student pou 8a analavei to assignment");
			int studentId = sc.nextInt();
			System.out.println("Dwse mou to id tou course pou 8a periexei to assignment");
			int courseId = sc.nextInt();
			String sql4 = "insert into student_has_course (ids,idc) values (?,?)";
			try {
				PreparedStatement pstmt = Utilities.conn.prepareStatement(sql4);
				pstmt.setInt(1, studentId);
				pstmt.setInt(2, courseId);
				pstmt.executeUpdate();		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(
						"O mathitis me id " + studentId + " exei idi kataxorithei sto course me id " + courseId);

			}
			String sql5 = "INSERT INTO `private_school`.`assignment_has_student_and_course` (`ida`, `ids`, `idc`) VALUES (?,?,?)";
			try {
				PreparedStatement pstmt = Utilities.conn.prepareStatement(sql5);
				pstmt.setInt(1, assignmentId);
				pstmt.setInt(2, studentId);
				pstmt.setInt(3, courseId);
				pstmt.executeUpdate();
				System.out.println("To assignment me id " + assignmentId + " kataxorithike epitixos sto course me id " + courseId +  " ka8ws kai sto mathiti me id " + studentId);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("To assignment me id " + assignmentId + " exei kataxorithei idi sto course me id " + courseId +  " ka8ws kai sto mathiti me id " + studentId);

			}
		
			Utilities.closeDataBase();
		}
		
}

package dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import util.Utilities;

public class DaoTrainer {

	private static Scanner sc;
	
	
	
	public DaoTrainer() {
		sc = new Scanner(System.in);

		String[] ar = { "", "", "", };
		System.out.println("Dwse mou to first name tou trainer ");
		ar[0] = sc.next();
		System.out.println("Dwse mou to last name tou trainer ");
		ar[1] = sc.next();
		System.out.println("Dwse mou to subject tou trainer");
		ar[2] = sc.next();

		if (!insertTrainer(ar))
			System.out.println("Den sothike sosta o neos trainer ");
		else {
			System.out.println("O trainer " + ar[0] + " " + ar[1] + " kataxorithike epitixos ");
		}

	}

	public static boolean insertTrainer(String[] fieldValues) {
		String sql = "INSERT INTO `private_school`.`trainer` (`first_name`, `last_name`, `subject`) VALUES (?,?,?);";
		Utilities.connect();

		try {

			PreparedStatement pstmt = Utilities.conn.prepareStatement(sql);
			pstmt.setString(1, fieldValues[0]);
			pstmt.setString(2, fieldValues[1]);
			pstmt.setString(3, fieldValues[2]);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Kati den pige kala me th vasi dedomenwn ");
			Utilities.closeDataBase();
			return false;
		}
		Utilities.closeDataBase();
		return true;
	}

	public static void selectTrainerPerCourse() {
		Utilities.connect();
		ResultSet rsCourse = null;
		ResultSet rsTrainer = null;

		String sql = "select distinct idc from course_has_trainer order by idc ";

		try {
			Statement st = Utilities.conn.createStatement();
			rsCourse = st.executeQuery(sql);
			while (rsCourse.next()) {
				int courseId = rsCourse.getInt("idc");
				System.out.println("Trainer per course cb" + courseId + " : ");
				String sql1 = "select first_name, last_name from Trainer where idt in (select idt from course_has_trainer where idc ="
						+ courseId + ")";
				Statement st1 = Utilities.conn.createStatement();
				rsTrainer = st1.executeQuery(sql1);
				while (rsTrainer.next()) {
					System.out.println(
							"\t\t " + rsTrainer.getString("first_name") + " " + rsTrainer.getString("last_name"));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Utilities.closeDataBase();
	}
	
	
	public static void trainerToCourse() {
		sc = new Scanner(System.in);
		Utilities.connect();
		String sql = "select idt , first_name , last_name from trainer";
		String sql2 = "select idc , titlec from course";
		System.out.println("\t\t---- Trainer table -----");
		try {
			Statement st = Utilities.conn.createStatement();
			ResultSet rsTrainer = st.executeQuery(sql);
			while (rsTrainer.next()) {
				System.out.println("\t\t" + rsTrainer.getInt("idt") + " " + rsTrainer.getString("first_name") + " "
						+ rsTrainer.getString("last_name"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("\t\t---- Course table -----");
		try {
			Statement st = Utilities.conn.createStatement();
			ResultSet rsCourse = st.executeQuery(sql2);
			while (rsCourse.next()) {
				System.out.println("\t\t" + rsCourse.getInt("idc") + " " + rsCourse.getString("titlec"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("\ndwse mou to trainer id pou 8a analavei to course");
		int trainerId = sc.nextInt();
		System.out.println("dwse mou to course id pou 8a analavei ");
		int courseId = sc.nextInt();
		String sql3 = "insert into course_has_trainer (idc,idt) values (?,?)";
		try {
			PreparedStatement pstmt = Utilities.conn.prepareStatement(sql3);
			pstmt.setInt(1, trainerId);
			pstmt.setInt(2, courseId);
			pstmt.executeUpdate();
			System.out.println(
					"O trainer me id " + trainerId + " kataxorithike epitixos sto course me id " + courseId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(
					"O trainer me id "  + trainerId + " exei idi kataxorithei sto course me id " + courseId);

		}
	
		Utilities.closeDataBase();
	}
}

-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: private_school
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assignment`
--

DROP TABLE IF EXISTS `assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment` (
  `ida` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titlea` varchar(30) NOT NULL,
  `description` varchar(30) DEFAULT NULL,
  `sub_date_time` datetime DEFAULT NULL,
  `oral_mark` double DEFAULT NULL,
  `total_mark` double DEFAULT NULL,
  PRIMARY KEY (`ida`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment`
--

LOCK TABLES `assignment` WRITE;
/*!40000 ALTER TABLE `assignment` DISABLE KEYS */;
INSERT INTO `assignment` VALUES (1,'World war 2',NULL,NULL,NULL,NULL),(2,'Planet Presentation',NULL,NULL,NULL,NULL),(3,'Engineering',NULL,NULL,NULL,NULL),(4,'Paleontology',NULL,NULL,NULL,NULL),(5,'Biology',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_has_student_and_course`
--

DROP TABLE IF EXISTS `assignment_has_student_and_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment_has_student_and_course` (
  `ida` int(10) unsigned NOT NULL,
  `ids` int(10) unsigned NOT NULL,
  `idc` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ida`,`ids`,`idc`),
  KEY `fk_Assignment_has_Student_has_Course_Student_has_Course1_idx` (`ids`,`idc`),
  KEY `fk_Assignment_has_Student_has_Course_Assignment1_idx` (`ida`),
  CONSTRAINT `fk_Assignment_has_Student_has_Course_Assignment1` FOREIGN KEY (`ida`) REFERENCES `assignment` (`ida`),
  CONSTRAINT `fk_Assignment_has_Student_has_Course_Student_has_Course1` FOREIGN KEY (`ids`, `idc`) REFERENCES `student_has_course` (`ids`, `idc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_has_student_and_course`
--

LOCK TABLES `assignment_has_student_and_course` WRITE;
/*!40000 ALTER TABLE `assignment_has_student_and_course` DISABLE KEYS */;
INSERT INTO `assignment_has_student_and_course` VALUES (1,1,1),(2,1,2),(3,1,3),(3,2,3),(4,3,4),(5,3,5),(5,4,5),(5,5,5);
/*!40000 ALTER TABLE `assignment_has_student_and_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `idc` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titlec` varchar(30) NOT NULL,
  `stream` varchar(30) NOT NULL,
  `type` varchar(30) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`idc`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'cb1','java','part time','2019-10-19','2020-03-15'),(2,'cb2','java','full time','2019-10-19','2020-01-15'),(3,'cb3','csharp','part time','2019-10-19','2020-03-15'),(4,'cb4','csharp','full time','2019-10-19','2020-01-15'),(5,'cb5','java','part time','2020-03-19','2020-09-20');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_has_trainer`
--

DROP TABLE IF EXISTS `course_has_trainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_has_trainer` (
  `idc` int(10) unsigned NOT NULL,
  `idt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idc`,`idt`),
  KEY `fk_Course_has_Trainer_Trainer1_idx` (`idt`),
  KEY `fk_Course_has_Trainer_Course_idx` (`idc`),
  CONSTRAINT `fk_Course_has_Trainer_Course` FOREIGN KEY (`idc`) REFERENCES `course` (`idc`),
  CONSTRAINT `fk_Course_has_Trainer_Trainer1` FOREIGN KEY (`idt`) REFERENCES `trainer` (`idt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_has_trainer`
--

LOCK TABLES `course_has_trainer` WRITE;
/*!40000 ALTER TABLE `course_has_trainer` DISABLE KEYS */;
INSERT INTO `course_has_trainer` VALUES (1,1),(2,2),(3,3),(4,4),(5,5);
/*!40000 ALTER TABLE `course_has_trainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `ids` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `date_of_birth` date NOT NULL,
  `tuition_fees` int(11) NOT NULL,
  PRIMARY KEY (`ids`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,'Marios','Kykkos','1988-01-12',2500),(2,'Nikos','Iwannou','1990-11-17',2000),(3,'Giannis','Stavrakakis','1995-07-06',1700),(4,'Zaxos','Papagewrgiou','1986-10-23',1900),(5,'Takis','Papadopoulos','1991-01-30',1800),(21,'Giwrgos','Lagios','1998-11-12',2000);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_has_course`
--

DROP TABLE IF EXISTS `student_has_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_has_course` (
  `ids` int(10) unsigned NOT NULL,
  `idc` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ids`,`idc`),
  KEY `fk_Student_has_Course_Course1_idx` (`idc`),
  KEY `fk_Student_has_Course_Student1_idx` (`ids`),
  CONSTRAINT `fk_Student_has_Course_Course1` FOREIGN KEY (`idc`) REFERENCES `course` (`idc`),
  CONSTRAINT `fk_Student_has_Course_Student1` FOREIGN KEY (`ids`) REFERENCES `student` (`ids`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_has_course`
--

LOCK TABLES `student_has_course` WRITE;
/*!40000 ALTER TABLE `student_has_course` DISABLE KEYS */;
INSERT INTO `student_has_course` VALUES (1,1),(1,2),(1,3),(2,3),(2,4),(3,4),(3,5),(4,5),(5,5);
/*!40000 ALTER TABLE `student_has_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trainer`
--

DROP TABLE IF EXISTS `trainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trainer` (
  `idt` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL,
  PRIMARY KEY (`idt`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainer`
--

LOCK TABLES `trainer` WRITE;
/*!40000 ALTER TABLE `trainer` DISABLE KEYS */;
INSERT INTO `trainer` VALUES (1,'Ilias','Kyrgios','java'),(2,'Giwrgos','Skoulos','java'),(3,'Lakis','Giannou','csharp'),(4,'Tasos','Parlalis','csharp'),(5,'Giannis','Anagnwstou','csharp'),(8,'Thanos','Galatas','java');
/*!40000 ALTER TABLE `trainer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-20 13:15:30
